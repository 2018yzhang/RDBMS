select App, Reviews from googleplaystore where Reviews >=100 order by Reviews DESC limit 10;
select App, Reviews from googleplaystore where Reviews >=100 order by Reviews limit 10;